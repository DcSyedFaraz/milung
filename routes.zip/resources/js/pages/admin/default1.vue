<template>
    <h1>
        HI
    </h1>
</template>

<script>
import './index';
export default {
    setup() {


        return {}
    }
}
</script>

<style  scoped>
@import url('./style.css');
</style>
